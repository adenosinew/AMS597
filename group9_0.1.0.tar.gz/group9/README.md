# AMS597
Respository for AMS 597 R Package
##分工
- Help file: Kexing Wu
- function 1: Jiale Tan
- function 2: Yicong Zhu
- function 3: Xining Zhang
- function 4: Yue Zhang
- function 5: Yuanjiao Wang

1) modified t-statistic of Kim et al.
2) corrected Z-test of Looney and Jones
3) MLE based test of Ekbohm under homoscedasticity
4) MLE based test of Lin and Stivers under heteroscedasticity
5) weighted Z-test combination
